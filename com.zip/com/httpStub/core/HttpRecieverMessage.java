package com.httpStub.core;
/**
class: HttpRecieverMessage
Purpose: Sets Up the receiver message.
Notes:
Author: Tim Lane
Date: 24/03/2014
**/

//import java.util.ArrayList;
//import java.util.List;
//import java.util.regex.Matcher;
//import java.util.regex.Pattern;

public class HttpRecieverMessage {
  
  private String httpRecieverMessage;
  
  
  
  
  
  
}
