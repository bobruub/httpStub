package com.httpStub.core;

/**
class: StubLog
Purpose: handle messaging
Notes:
Author: Tim Lane
Date: 25/03/2014

**/
public class StobLog {
 
  // Create an HTTPStub for a particular TCP port
  public StobLog()
  {
    
  }

  public void addMessage(String msg){
    
    System.out.println(msg);

    
  }
  
}
